import res_partner
import lead
import res_code
import sale_order_configuration
import update_customer_data